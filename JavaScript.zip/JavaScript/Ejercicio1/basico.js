function entrar() {
    var r = confirm("¿Eres mayor de edad?");
    if (r == true) {
        txt = "Has aceptado";
    } else {
        location.href = "https://sites.google.com/site/websol018/sesiones";
    }
}

document.oncontextmenu = function() {
    return false
}

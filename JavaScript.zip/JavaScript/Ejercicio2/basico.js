function popup() {
    window.open("https://sites.google.com/site/websol018/sesiones", 'Popup', 'width=300,height=200,left = 390,top = 50');
}

window.setInterval("popup();", 5000, "JavaScript");
function validar() {
    email = document.getElementById("mail").value;
    pass = document.getElementById("pass").value;
    fecha = document.getElementById("fecha").value;

    correcto = true;
    var expreg = new RegExp("/^[0-9]{6,}/");
   

    if(email!="" && pass!="" && fecha!="") {
        correcto = true;
    } else {
        correcto = false;
    }

    if(expreg.test(pass)) {
        correcto = true;
    } else {
        correcto = false;
    }

    hoy = Date();

    if(fecha.getTime >= hoy.getTime()) {
        correcto = true;
    } else {
        correcto = false;
    }

    if(correcto==true) {
        document.getElementById("caja").innerHTML = "Se ha añadido correctamente";
    } else {
        document.getElementById("caja").innerHTML = "Error en los campos";
    }
}
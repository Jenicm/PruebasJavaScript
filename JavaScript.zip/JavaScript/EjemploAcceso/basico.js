function validar() {
    var user = $("#user").val();
    var pass = $("#pass").val();

    if(user == "admin" && pass == "123456") {
        document.cookie = "username=ABC123";
        $("#incorrecto").html("Acceso correcto");
        //location.href = "https://www.w3schools.com/js/js_cookies.asp";
    } else {
        $("#incorrecto").html("Usuario o contraseña incorrectos");
    }
}